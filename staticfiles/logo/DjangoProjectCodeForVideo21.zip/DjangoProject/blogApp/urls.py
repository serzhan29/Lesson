# created manually 
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='blog-homepage'),
    path('about', views.about, name='blog-about'),
    path('add-category', views.addCategory, name='blog-add-category'),
    path('add-post', views.addPost, name='blog-add-post'),
]
