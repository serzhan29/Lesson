from django.shortcuts import render, redirect
from django.contrib import messages
from . import forms
from django.contrib.auth.decorators import login_required
from django.utils.text import slugify
from . import models
# Create your views here.

def unique_slug(title):
    base_slug = slugify(title)
    slug_query = models.BlogPost.objects.filter(slug=base_slug).first()
    count = 0
    if slug_query:
        count += 1
        return base_slug + '-' + str(count)
    else:
        return base_slug

def home(request):
    string = "Hello World again!"
    messages.success(
        request,
        'This is a flash message'
    )
    return render(
        request,
        'blogApp/index.html',
        {
            'string': string
        }
    )

def about(request):
    return render(
        request,
        'blogApp/about.html',
        {
            
        }
    )
    
@login_required(login_url='/auth/login')
def addCategory(request):
    form = forms.AddCategoryForm(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            form.instance.username = request.user.username
            category = form.cleaned_data['category_name']
            form.save()
            messages.success(
                request,
                f"Your category: {category} is now added to the database!"
            )
            return redirect('/')
        else:
            messages.warning(
                request,
                f'There are errors in form!\n{form.errors}'
            )
            return redirect('/add-category')
    else:
        return render(
            request,
            'blogApp/add-category.html',
            {
                'form': form
            }
        )
        
@login_required(login_url='/auth/login')
def addPost(request):
    form = forms.AddPostForm(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            form.instance.author = request.user
            title = form.cleaned_data['title']
            form.instance.slug = unique_slug(title)
            form.save()
            messages.success(
                request,
                'Your post has been added!'
            )
            return redirect('/')
        else:
            messages.warning(
                request,
                f'There are errors in form!\n{form.errors}'
            )
            return render(
                request,
                'blogApp/add-post.html',
                {
                    'form': form
                }
            )
    else:
        return render(
            request,
            'blogApp/add-post.html',
            {
                'form': form
            }
        )