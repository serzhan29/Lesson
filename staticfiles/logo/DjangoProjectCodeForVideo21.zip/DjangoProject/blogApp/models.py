from django.db import models
from django.contrib.auth.models import User
from ckeditor.fields import RichTextField
from django_ckeditor_5.fields import CKEditor5Field

# Create your models here.

class Categories(models.Model):
    category_name = models.CharField(max_length=255)
    date_added = models.DateField(auto_now_add=True)
    username = models.CharField(max_length=255)
    
    def __str__(self):
        return self.category_name
    
class BlogPost(models.Model):
    title = models.TextField()
    tagline = models.TextField()
    content = CKEditor5Field('Text', config_name='extends')
    slug = models.TextField()
    thumbnail = models.URLField(default = None, null=True, blank=True)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    date_posted = models.DateField(auto_now_add=True)
    category = models.CharField(max_length=255)
    
    def __str__(self):
        return f'{self.title} | {self.author.username}'