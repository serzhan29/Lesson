# created manually 
from django import forms
from . import models
from django_ckeditor_5.widgets import CKEditor5Widget

category_list = []
categoryObjects = models.Categories.objects.all()
for categories in categoryObjects:
    category_list.append(
        (f'{categories}', f'{categories}')
    )
# print(category_list)

class AddCategoryForm(forms.ModelForm):
    class Meta:
        model = models.Categories
        fields = ('category_name',)
        widgets = {
            'category_name': forms.TextInput(
                attrs={
                    'class': 'form-control'
                }
            )
        }
        
class AddPostForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
          super().__init__(*args, **kwargs)
          self.fields["content"].required = False
    class Meta:
        model = models.BlogPost
        fields = (
            'title',
            'tagline',
            'thumbnail',
            'category',
            'content',
        )
        widgets = {
            'title': forms.TextInput(
                attrs={
                    'class': 'form-control'
                }
            ),
            'tagline': forms.TextInput(
                attrs={
                    'class': 'form-control'
                }
            ),
            'thumbnail': forms.URLInput(
                attrs={
                    'class': 'form-control'
                }
            ),
            'category': forms.Select(
                choices=category_list,
                attrs={
                    'class': 'form-control'
                }
            ),
            "content": CKEditor5Widget(
                attrs={"class": "django_ckeditor_5"}, config_name="extends"
            )
        }
        required = {
            'thumbnail': False
        }