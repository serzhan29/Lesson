# created manually
from django.urls import path
from . import views
from django.contrib.auth import views as authViews

urlpatterns = [
    path('register', views.register, name="auth-register"),
    path('login', views.loginUser, name="auth-login"),
    path('logout', views.logoutUser, name="auth-logout"),
    path('edit-user', views.editUser, name="auth-edit-user"),
    path('edit-password', views.editPassword, name="auth-edit-password"),
    path('delete-user', views.deleteUser, name="auth-delete-user"),
    path('create-profile', views.createProfile, name="auth-create-profile"),
    path('edit-profile', views.editProfile, name="auth-edit-profile"),
    path('dashboard', views.dashboard, name="auth-dashboard"),
    
    path('reset-password', views.CustomPasswordResetView.as_view(), name="reset_password"), # email input done
    path('reset-password-sent', authViews.PasswordResetDoneView.as_view(template_name='blogAuthApp/reset-done.html'), name="password_reset_done"), # check email for more instructions
    path('reset/<uidb64>/<token>', views.CustomPasswordResetConfirmView.as_view(), name="password_reset_confirm"), # actual password change input boxes done
    path('reset-password-complete', authViews.PasswordResetCompleteView.as_view(template_name='blogAuthApp/reset-complete.html'), name="password_reset_complete") # confirmation for password change   
]
