from django.db import models
from django.contrib.auth.models import User
from django.utils.text import slugify
from uuid import uuid4

# Create your models here.

class Profile(models.Model):
    user = models.OneToOneField(
        User,
        on_delete = models.CASCADE,
        null = True,
    )
    slug = models.SlugField(
        max_length = 2000,
        unique = True,
        blank = True,
    )
    about_user = models.TextField()
    profile_pic = models.ImageField(
        null=True,
        blank=True,
        upload_to='images/profile-pic'
    )
    social_link = models.URLField(
        null=True,
        blank=True
    )
    
    def __str__(self):
        return self.user.username
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(str(uuid4()))
        super().save(*args, **kwargs)
    
    