from django.shortcuts import render, redirect
from . import forms
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth import views as authViews

# Create your views here.

def register(request):
    form = forms.RegisterForm(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            email_user = form.cleaned_data['email']
            email_query = User.objects.filter(email=email_user).first()
            if email_query:
                messages.warning(
                    request,
                    'Invalid Email, try again with a different one'
                )
                return redirect('/auth/register')
            else:
                form.save()
                messages.success(
                    request,
                    'You have been registered to our website'
                )
                return redirect('/')
        else:
            messages.warning(
                request,
                f'Your form has errors: \n{form.errors}'
            )
            return redirect('/auth/register')
    else:
        return render(
            request,
            'blogAuthApp/register.html',
            {
                'form': form
            }
        )
        
def loginUser(request):
    form = forms.LoginForm(request.POST)
    if request.user.is_authenticated:
        messages.warning(
            request,
            'You are already logged in!'
        )
        return redirect('/')
    if request.method == 'POST':
        if form.is_valid():
            attempt = authenticate(
                request,
                username = form.cleaned_data['username'],
                password = form.cleaned_data['password']
            )
            if attempt:
                login(
                    request,
                    attempt
                )
                messages.success(
                    request,
                    'You are now logged in!'
                )
                return redirect('/')
            else:
                messages.warning(
                    request,
                    'Invalid username or password'
                )
                return redirect('/auth/login')
        else:
            messages.warning(
                request,
                f'Your form has errors: \n{form.errors}'
            )
            return redirect('/auth/login')
    else:
        return render(
            request,
            'blogAuthApp/login.html',
            {
                'form': form
            }
        )
        
@login_required(login_url='/auth/login')
def logoutUser(request):
    logout(request)
    messages.success(
        request,
        'Logout Successful!'
    )
    return redirect('/auth/login')

@login_required(login_url='/auth/login')
def editUser(request):
    form = forms.UserEditForm(request.POST or None, instance=request.user)
    if request.method == 'POST':
        if form.is_valid():
            form_email = form.cleaned_data['email']
            email_query = User.objects.exclude(pk=request.user.pk).filter(email=form_email)
            if email_query:
                messages.warning(
                    request,
                    'This email is associated with another account'
                )
                return redirect('/auth/edit-user')
            else:
                form.save()
                messages.success(
                    request,
                    'Your account has been edited!'
                )
                return redirect('/')
        else:
            messages.warning(
                request,
                f'Your form has errors: \n{form.errors}'
            )
            return redirect('/auth/edit-user')
    return render (
        request,
        'blogAuthApp/edit-user.html',
        {
            'form': form
        }
    )
  
@login_required(login_url="/auth/login")
def editPassword(request):
    form = forms.EditPassword(request.user, request.POST)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(
                request,
                'Password Changed successfully!'
            )
            return redirect('/')
        else:
            messages.warning(
                request,
                f'Your form has errors: \n{form.errors}'
            )
            return redirect('/auth/change-password')
    else:
        return render(
            request,
            'blogAuthApp/password-change.html',
            {
                'form': form
            }
        )
        
@login_required(login_url='/auth/login')
def deleteUser(request):
    user_query = User.objects.filter(username=request.user.username).first()
    user_query.delete()
    messages.success(
        request,
        'Your Account has been Deleted!'
    )
    return redirect('/')

@login_required(login_url='/auth/login')
def createProfile(request):
    form = forms.ProfileForm(request.POST, request.FILES)
    profile_check = None
    try:
        profile_check = request.user.profile
    except Exception as error:
        profile_check = None
    if profile_check is not None:
        messages.warning(
            request,
            'your profile already exists!'
        )
        return redirect('/')
    if request.method=="POST":
        if form.is_valid():
            form.instance.user = request.user
            form.save()
            messages.success(
                request,
                'Your profile is created!'
            )
            return redirect('/')
        else:
            messages.warning(
                request,
                f'Your form has errors: \n{form.errors}'
            )
            return redirect('/auth/create-profile')
    else:
        return render(
            request,
            'blogAuthApp/create-profile.html',
            {
                'form': form
            }
        )

@login_required(login_url='/auth/login')
def editProfile(request):
    profile_query = None
    try:
        profile_query = request.user.profile
    except Exception as error:
        profile_query = None
    if profile_query == None:
        messages.warning(
            request,
            'You have not created a profile yet'
        )
        return redirect('/')    
    form = forms.ProfileForm(request.POST, request.FILES, instance=request.user.profile)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(
                request,
                'Your profile has been edited'
            )
            return redirect('/')
        else:
            messages.warning(
                request,
                f'Your form has errors: \n{form.errors}'
            )
            return redirect('/auth/edit-profile')
    else:
        form = forms.ProfileForm(instance=request.user.profile)
        return render(
            request,
            'blogAuthApp/edit-profile.html',
            {
                'form': form
            }
        )

@login_required(login_url='/auth/login')
def dashboard(request):
    return render(
        request,
        'blogAuthApp/dashboard.html',
        {
            
        }
    )
    
class CustomPasswordResetView(authViews.PasswordResetView):
    form_class = forms.CustomPasswordResetForm
    template_name = 'blogAuthApp/password-reset.html'
    
class CustomPasswordResetConfirmView(authViews.PasswordResetConfirmView):
    form_class = forms.CustomSetPasswordForm
    template_name = 'blogAuthApp/password-set.html'
    